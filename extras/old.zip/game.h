#ifndef GAME_H
#define GAME_H

// Included Libraries
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

// Varables
// Size assignments
#define DIALOGUE_SIZE 512 // Size for Dialogue Container
#define MAX_INVENTORY_SIZE 5 // Max size for Inventory Container
// Tile types
#define EMPTY 0
#define PLAYER 1
#define WALL 2
#define CHAIR 3
#define VERT_DOOR_CLOSED 4
#define HOR_DOOR_CLOSED 5
#define BAR 6
#define PANEL_FACE_LEFT 7
#define PANEL_FACE_RIGHT 8
#define VERT_DOOR_OPEN 9
#define HOR_DOOR_OPEN 10
// Tile properties
#define INTERACTABLE (1 << 0) // Can be interacted with
#define SOLID (1 << 1) // Can not be passed through (blocks player movement)
#define LOCKED (1 << 2) // Requires key to be used (typically a door)
#define HAS_KEY (1 << 3) // Tile contains a key for player to collect
// Item types
#define KEY_ITEM 1 // Key Item ID

// Global Variables
extern int mapWidth, mapHeight, **map; // Map Dimensions and Data Container
extern struct Player player; // Player struct
extern char dialogue[DIALOGUE_SIZE]; // Dialogue Holder
extern int debugMode; // Special Mode with Special Functions
extern int startX, startY; // Declaration of starting coordinates
extern int inventorySize;
extern int specialCount;

// Structures
struct Player { // Player
	int x, y; // Player coordinates
};
struct InventoryItem { // Inventory items
	int type; // Item ID
};
struct SpecialInteraction { // Special Interactions
	int x, y; // Interaction coordinates
	char message[256]; // Resulting dialogue 
	char action[64]; // New field to store action commands
};
// Declarations
extern struct SpecialInteraction *specialInteractions;
extern struct InventoryItem inventory[MAX_INVENTORY_SIZE];

// Function declarations
// Inventory
void addItemToInventory(int type);
void removeItemFromInventory(int type);
int hasItem(int type);
// Map loading
void getMapSize(const char *filename);
void loadMapData(const char *filename);
void loadMap(char* mapName);
// Player movement
void playerInput(int **screen);
int isValidMove(int x, int y, int **screen);
void movePlayer(int **map, char direction);
// Player interaction
void interact(int **map);
void handleInteraction(int x, int y, int **map);
int getTileProperties(int x, int y, int **screen);
// Graphics
void draw(int **screen, int playerX, int playerY);
void clearScreen();
void printd(const char *message, ...);

#endif