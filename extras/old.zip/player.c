#include "game.h"

extern struct InventoryItem inventory[MAX_INVENTORY_SIZE];

int isValidMove(int x, int y, int ** map) { // Check if the Player's Move is Okay
	// Enforce boundaries
	if (x < 0 || x >= mapWidth || y < 0 || y >= mapHeight) { // Outside of boundaries
		return 0; // No Can Do
	}

	// Check destination tile
	int properties = getTileProperties(x, y, map); // Find Properties of Destination Tile
	if (properties & SOLID && debugMode == 0) { // Solid Tile, Player Can't Continue
		return 0; // No Can Do
	}

	return 1; // Go ahead
}

// Handle player input
void playerInput(int **screen) {
	char input[6];
	scanf("%5s", input);

	// Process commands
	int interactX = player.x;
	int interactY = player.y;
	int movePerformed = 0;
	int interactionMode = 0;

	for (int i = 0; input[i] != '\0'; i++) {
		char cmd = input[i];

		if (interactionMode) {
			if (cmd == 'w') interactY--;
			else if (cmd == 's') interactY++;
			else if (cmd == 'a') interactX--;
			else if (cmd == 'd') interactX++;
			else if (cmd == 'e') debugMode = 1;
			else {
				interactX = player.x;
				interactY = player.y;
			}
			handleInteraction(interactX, interactY, screen);
			interactionMode = 0;
			continue;
		}

		if (cmd == 'w') {
			if (isValidMove(interactX, interactY - 1, screen)) {
				interactY--;
				movePerformed = 1;
			} else {
				printd("Can't go up.");
			}
		} else if (cmd == 'd') {
			if (isValidMove(interactX + 1, interactY, screen)) {
				interactX++;
				movePerformed = 1;
			} else {
				printd("Can't go right.");
			}
		} else if (cmd == 's') {
			if (isValidMove(interactX, interactY + 1, screen)) {
				interactY++;
				movePerformed = 1;
			} else {
				printd("Can't go down.");
			}
		} else if (cmd == 'a') {
			if (isValidMove(interactX - 1, interactY, screen)) {
				interactX--;
				movePerformed = 1;
			} else {
				printd("Can't go left.");
			}
		} else if (cmd == 'q') {
			clearScreen();
			printd("See you soon! Or not. Hopefully not.");
			exit(0);
		} else if (cmd == 'h') {
			printd("wasd:move i:inventory e[wasd]:interaction q:quit.");
		} else if (cmd == 'e') {
			interactionMode = 1;
			interactX = player.x;
			interactY = player.y;
		} else if (cmd == 'i') {
			if (inventorySize == 0) {
				printd("(empty)");
			}
			for (int j = 0; j < inventorySize; j++) {
				switch (inventory[j].type) {
					case KEY_ITEM:
						printd("Key");
						break;
					default:
						printd("Unknown item");
						break;
				}
			}
		}
	}

	if (movePerformed) {
		player.x = interactX;
		player.y = interactY;
	}
}