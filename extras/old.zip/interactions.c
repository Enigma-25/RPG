#include "game.h"

// Variable Assignments
char dialogue[DIALOGUE_SIZE] = "";

void executeAction(const char *action) {
	if (strncmp(action, "ADD_ITEM(", 9) == 0) {
		int itemId;
		if (sscanf(action, "ADD_ITEM(%d)", &itemId) == 1) {
			addItemToInventory(itemId);
			printd("[Item added to inventory]");
			return;
		}
		return;
	}
	if (strcmp(action, "REMOVE_ITEM(1)") == 0) {
		removeItemFromInventory(1);
		printd("[Key removed from inventory]");
		return;
	}
}

void handleInteraction(int x, int y, int **screen) { // Function to handle player interactions with tiles
	if (x < 0 || x >= mapWidth || y < 0 || y >= mapHeight) {
		printd("Invalid interaction target.");
		return;
	}

	for (int i = 0; i < specialCount; i++) {
		if (specialInteractions[i].x == x && specialInteractions[i].y == y) {
			printd(specialInteractions[i].message);

	    // Process actions
			if (strlen(specialInteractions[i].action) > 0) {
				executeAction(specialInteractions[i].action);
			}
			return;
		}
	}

  // Default/Fallback interactions
	int tile = screen[y][x];
	int properties = getTileProperties(x, y, screen);
	if (!(properties & INTERACTABLE)) {
		printd("Nothing to interact with here.");
		return;
	}

	if (tile == CHAIR) {
		printd("It's a chair. It's chairing.");
		return;
	}

  // Doors
	if (tile == VERT_DOOR_CLOSED || tile == HOR_DOOR_CLOSED || tile == VERT_DOOR_OPEN || tile == HOR_DOOR_OPEN) {

	int isHorizontal = (tile == HOR_DOOR_CLOSED || tile == HOR_DOOR_OPEN);
	int isClosed = (tile == HOR_DOOR_CLOSED || tile == VERT_DOOR_CLOSED);

    // Check if it is the locked door (to be deprecated [hopefully])
	if (isHorizontal && isClosed && x == 3 && y == 10) {
		if (hasItem(KEY_ITEM)) {
			removeItemFromInventory(KEY_ITEM);
			printd("You used the key and unlocked the door.");
		} else {
			printd("This door is locked. Where is the key?");
			return;
		}
	}
    // Not working open/close door logic
	screen[y][x] = isClosed ? (isHorizontal ? HOR_DOOR_OPEN : VERT_DOOR_OPEN) : (isHorizontal ? HOR_DOOR_CLOSED : VERT_DOOR_CLOSED);
		printd(isClosed ? "You opened a door." : "You closed a door.");
		return;
	}

	if (tile == PANEL_FACE_LEFT) {
		printd("It's a panel[L].");
		return;
		}

	if (tile == PANEL_FACE_RIGHT) {
		printd("It's a panel[R].");
		return;
		}

	if (tile == BAR) {
		printd("It's pretty long (ay yo?).");
		return;
		}

	  printd("Nothing to interact with here."); // Is not any of the other tiles.
	}

	int getTileProperties(int x, int y, int **screen) {
	  int tile = screen[y][x]; // Check tile coordinate

	  switch (tile) { // Potential properties
	  case VERT_DOOR_CLOSED:
	  case HOR_DOOR_CLOSED:
	  	return INTERACTABLE | SOLID;
	  case WALL:
	  	return SOLID;
	  case PANEL_FACE_LEFT:
	  case CHAIR:
	  	return INTERACTABLE;
	  case BAR:
	  case PANEL_FACE_RIGHT:
	  	return INTERACTABLE | SOLID;
	  default:
	  	return 0;
  }
}