#include "game.h"

// Write Screen Buffer
void draw(int ** map, int playerX, int playerY) {
	int ** screen = (int ** ) malloc(mapHeight * sizeof(int * ));
	for (int i = 0; i < mapHeight; i++) {
		screen[i] = (int * ) malloc(mapWidth * sizeof(int));
	}
	for (int row = 0; row < mapHeight; row++) {
		for (int col = 0; col < mapWidth; col++) {
			screen[row][col] = map[row][col];
		}
	}
  screen[player.y][player.x] = PLAYER; // Insert Player at Player Coordinates

  clearScreen();
  // Draw Buffer to Screen
  for (int row = 0; row < mapHeight; row++) {
  	for (int col = 0; col < mapWidth; col++) {
  		if (screen[row][col] == EMPTY)
        printf("　"); // Empty Tile
      else if (screen[row][col] == WALL)
      	printf("Ｈ");
      else if (screen[row][col] == PLAYER)
      	printf("Ｏ");
      else if (screen[row][col] == VERT_DOOR_CLOSED)
      	printf("｜");
      else if (screen[row][col] == VERT_DOOR_OPEN)
      	printf("＼");
      else if (screen[row][col] == HOR_DOOR_CLOSED)
      	printf("＿");
      else if (screen[row][col] == HOR_DOOR_OPEN)
      	printf("／");
      else if (screen[row][col] == PANEL_FACE_LEFT)
      	printf("［");
      else if (screen[row][col] == CHAIR)
      	printf("＃");
      else if (screen[row][col] == PANEL_FACE_RIGHT) {
      	printf("］");
      } else if (screen[row][col] == BAR) {
      	printf("＝");
      } else {
        printf(" "); // Default/Error Tile
      }
    }
    printf("\n");
  }

  printf("%s\n", dialogue); // Print Dialogue
  strcpy(dialogue, ""); // Clear Dialogue Afterward

  // Free the screen buffer
  for (int i = 0; i < mapHeight; i++) {
  	free(screen[i]);
  }
  free(screen);
  fflush(stdout);
}

// Dialogue push system
void printd(const char *message, ...) {
	va_list args;
	va_start(args, message);

	const char *speaker = va_arg(args, const char *);

	char formattedMessage[DIALOGUE_SIZE];
	char *dst = formattedMessage;
	const char *src = message;

  while (*src && (dst - formattedMessage) < DIALOGUE_SIZE - 3) { // Ensure space for replacement
  	if (src[0] == '-' && src[1] == '-') {
  		*dst++ = '-';
  		*dst++ = '\n';
  		*dst++ = '-';
      src += 2; // Skip "--"
    } else {
    	*dst++ = *src++;
    }
  }
  *dst = '\0'; // Null terminate the formatted message

  if (speaker == NULL || (unsigned long)speaker < 256) { // If speaker is not specified
  	snprintf(dialogue, DIALOGUE_SIZE, "* \"%s\"", formattedMessage);
  } else {
    snprintf(dialogue, DIALOGUE_SIZE, "%s: \"%s\"", speaker, formattedMessage); // Include speaker name
  }

  va_end(args);
}

void clearScreen() { // Function to clear screen because it's easier
  printf("\e[1;1H\e[2J"); // ANSI escape sequence to clear screen
  fflush(stdout); // Flush ouput buffer *insert toilet flush sound*
}