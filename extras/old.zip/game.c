#include "game.h"

// Variable Assignments
int debugMode = 0;
struct Player player = {0, 0};

int main() {
	loadMap("house");
	player.x = startX;
	player.y = startY;

	int status = 0;
	printd("Enter \"h\" for controls.");

while (status != 1) {
	clearScreen();
	draw(map, player.x, player.y);
	if (player.y == 10 && player.x == 3) {
		status = 1;
	}
	if (debugMode == 1) {
		printf("x:%d y:%d\n", player.x, player.y);
	}
	playerInput(map);
}

clearScreen();
printf("That is the end of the demo's demo.\n");

for (int i = 0; i < mapHeight; i++) {
	free(map[i]);
}
free(map);

return 0;
}