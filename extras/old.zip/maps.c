#include "game.h"

// Variable Assignments
int mapWidth = 0;
int mapHeight = 0;
int **map = NULL;
struct SpecialInteraction *specialInteractions = NULL;
int specialCount = 0;
int startX = 0;
int startY = 0;

void getMapSize(const char *filename) {
	FILE *file = fopen(filename, "r");
	if (!file) {
		printf("Error: Could not open file %s\n", filename);
		exit(1);
	}

	char line[256];
	mapHeight = 0;
	mapWidth = 0;

  // First pass: Determine dimensions
	while (fgets(line, sizeof(line), file)) {
		int lineLength = strlen(line);
		while (lineLength > 0 && (line[lineLength - 1] == '\n' || line[lineLength - 1] == ' ')) {
			line[lineLength - 1] = '\0';
			lineLength--;
		}
		if (lineLength > mapWidth) {
			mapWidth = lineLength;
		}
		mapHeight++;
	}
	fclose(file);

  // Allocate memory for the map (Ensure proper initialization)
	map = malloc(mapHeight * sizeof(int *));
	if (!map) {
		printf("Error: Memory allocation failed for map rows.\n");
		exit(1);
	}

	for (int i = 0; i < mapHeight; i++) {
		map[i] = malloc(mapWidth * sizeof(int));
		if (!map[i]) {
			printf("Error: Memory allocation failed for map columns at row %d.\n", i);
			exit(1);
		}
	}
}

// Function to load the map from file
// Global variables for player start position
int playerStartX = 0;
int playerStartY = 0;

void loadMapData(const char *filename) {
	FILE *file = fopen(filename, "r");
	if (!file) {
		printf("Error: Could not open file %s\n", filename);
		exit(1);
	}

	char line[512];
	int row = 0;
	int readingSpecialSection = 0;
	int specialAlloc = 10;
	specialInteractions = malloc(specialAlloc * sizeof(struct SpecialInteraction));
	if (specialInteractions == NULL) {
		printf("Error: Memory allocation failed for specialInteractions.\n");
		exit(1);
	}
	specialCount = 0;

	while (fgets(line, sizeof(line), file) && row < mapHeight) {
        // Remove trailing newline or spaces
		size_t len = strlen(line);
		while (len > 0 && (line[len - 1] == '\n' || line[len - 1] == ' ')) {
			line[len - 1] = '\0';
			len--;
		}

        // Detect special sections
		if (strncmp(line, "SPECIAL", 7) == 0) {
			readingSpecialSection = 1;
			continue;
		}
		if (strncmp(line, "START:", 6) == 0) {
			sscanf(line + 6, "%d,%d", &startX, &startY);
			continue;
		}

        // Load map data if not in the special section
		if (!readingSpecialSection) {
			int col = 0;
			char *token = strtok(line, " \n");
			while (token != NULL && col < mapWidth) {
				map[row][col] = atoi(token);
				token = strtok(NULL, " \n");
				col++;
			}
			row++;
		} else {
            // Parsing special interactions
			int x, y;
			char msg[256];
			char action[64];

			if (sscanf(line, "%d,%d: %255[^|]|%63[^\n]", &x, &y, msg, action) >= 2) {
				if (specialCount >= specialAlloc) {
					specialAlloc *= 2;
					specialInteractions = realloc(specialInteractions, specialAlloc * sizeof(struct SpecialInteraction));
					if (specialInteractions == NULL) {
						printf("Error: Memory reallocation failed for specialInteractions.\n");
						exit(1);
					}
				}

                // Store special interaction
				specialInteractions[specialCount].x = x;
				specialInteractions[specialCount].y = y;
				strncpy(specialInteractions[specialCount].message, msg, sizeof(specialInteractions[specialCount].message) - 1);
				specialInteractions[specialCount].message[sizeof(specialInteractions[specialCount].message) - 1] = '\0';

				if (strlen(action) > 0) {
					strncpy(specialInteractions[specialCount].action, action, sizeof(specialInteractions[specialCount].action) - 1);
					specialInteractions[specialCount].action[sizeof(specialInteractions[specialCount].action) - 1] = '\0';
				} else {
					specialInteractions[specialCount].action[0] = '\0';
				}

				specialCount++;
			}
		}
	}

	fclose(file);
}

void loadMap(char* mapName) {
	char mapAddress[64];
  snprintf(mapAddress, sizeof(mapAddress), "../maps/%s/map.cmap", mapName);
  getMapSize(mapAddress);
  loadMapData(mapAddress);
}