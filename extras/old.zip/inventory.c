#include "game.h"

struct InventoryItem inventory[MAX_INVENTORY_SIZE];
int inventorySize = 0;

void addItemToInventory(int type) {
	if (inventorySize < MAX_INVENTORY_SIZE) {
		inventory[inventorySize].type = type;
		inventorySize++;
	}
}

int hasItem(int type) {
	for (int i = 0; i < inventorySize; i++) {
		if (inventory[i].type == type) {
            return 1;  // Item found
          }
        }
    return 0;  // Item not found
  }

  void removeItemFromInventory(int type) {
  	for (int i = 0; i < inventorySize; i++) {
  		if (inventory[i].type == type) {
  			for (int j = i; j < inventorySize - 1; j++) {
  				inventory[j] = inventory[j + 1];
  			}
  			inventorySize--;
  			return;
  		}
  	}
  }